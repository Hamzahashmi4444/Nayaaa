MailHost


  The MailHost product provides support for sending email from
  within the Zope environment using MailHost objects.

  Email can optionally be encoded using Base64, Quoted-Printable
  or UUEncode encoding.
