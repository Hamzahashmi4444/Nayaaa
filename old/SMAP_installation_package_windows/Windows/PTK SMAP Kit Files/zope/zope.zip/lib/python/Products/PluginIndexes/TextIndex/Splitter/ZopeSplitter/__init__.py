from ZopeSplitter import ZopeSplitter

def Splitter(txt,stopwords={},encoding="latin1"):
    return ZopeSplitter(txt,stopwords)
